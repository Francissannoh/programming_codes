﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SalesDB
{
    public partial class Orders : Form
    {
        public Orders()
        {
            InitializeComponent();
        }

        private void ordersBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {

            bool flag;
            flag = true;
            if (customersIDTextBox.Text == "")
            {
                errorProvider1.SetError(customersIDTextBox, "CustomerID. is required");
                flag = false;
            }
            else
                errorProvider1.SetError(customersIDTextBox, "");
            if (order_StatusComboBox.Text == "")
            {
                errorProvider1.SetError(order_StatusComboBox, "Select Order Status");
                flag = false;
            }
            else
                errorProvider1.SetError(order_StatusComboBox, "");


            if (flag == false)
                return;
            else
            {
            }

            this.Validate();
            this.ordersBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.salesDBDataSet);
            MessageBox.Show("Order Updated Successfully");
        }

        private void Orders_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'salesDBDataSet.Orders' table. You can move, or remove it, as needed.
            this.ordersTableAdapter.Fill(this.salesDBDataSet.Orders);

        }
    }
}
 