﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SalesDB
{
    public partial class Customers : Form
    {
        public Customers()
        {
            InitializeComponent();
        }

        private void customersBindingNavigatorSaveItem_Click(object sender, EventArgs e)
        {
            if (firstNameTextBox.Text == "")
            {
                MessageBox.Show("Please enter FirstName", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                firstNameTextBox.Focus();
                return;
            }
            if (lastNameTextBox.Text == "")
            {
                MessageBox.Show("Please enter Last name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                lastNameTextBox.Focus();
                return;
            }
           

            this.Validate();
            this.customersBindingSource.EndEdit();
            this.tableAdapterManager.UpdateAll(this.salesDBDataSet);

        }

        private void Customers_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'salesDBDataSet.Customers' table. You can move, or remove it, as needed.
            this.customersTableAdapter.Fill(this.salesDBDataSet.Customers);

        }

        private void toolStripButton1_Click(object sender, EventArgs e)
        {
            this.Hide();
            MainForm frm = new MainForm();
        }
    }
}
