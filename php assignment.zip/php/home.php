<?php

session_start();
if(!isset($_SESSION['username'])){
    header('location:login.php');
}
?>
<html>
    <head>
        <title> HOME PAGE</title>
        <link rel="stylesheet" type="text/css" href="style.css">
        <link rel="stylesheet" type="text/css" href="https://fonts.googleapis.com/css?family=Poppins:wght@200;300;400;500;600;700&display=swap">
    </head>
    <body>
        <div class="container"> 
        <a class="float-right" href="logout.php">LOGOUT</a>
        <h1> WELCOME <?php echo $_SESSION['username'] ; ?> </h1>
        </div>
    </body>
</html>